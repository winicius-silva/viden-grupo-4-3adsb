package br.com.bandtec.arquivocsv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArquivoCsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArquivoCsvApplication.class, args);
	}

}
